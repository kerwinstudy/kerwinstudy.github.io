create view level1 as
select `web_db`.`data`.`Site`          AS `Site`,
       `web_db`.`data`.`Dimension`     AS `Dimension`,
       `web_db`.`data`.`longitude`     AS `longitude`,
       `web_db`.`data`.`altitude(*10)` AS `altitude(*10)`,
       `web_db`.`data`.`year`          AS `year`,
       `web_db`.`data`.`month`         AS `month`,
       `web_db`.`data`.`day`           AS `day`,
       `web_db`.`data`.`1-6(h)`        AS `1-6(h)`,
       `web_db`.`data`.`6-12(h)`       AS `6-12(h)`,
       `web_db`.`data`.`12-18(h)`      AS `12-18(h)`,
       `web_db`.`data`.`18-24(h)`      AS `18-24(h)`
from `web_db`.`data`
where ((`web_db`.`data`.`day` > 0) and (`web_db`.`data`.`day` < 16));

